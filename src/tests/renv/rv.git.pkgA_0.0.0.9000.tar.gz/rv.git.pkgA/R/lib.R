#' @export
test_no_depends_package <- function() {
  print("rv.git.pkgA installed")
}